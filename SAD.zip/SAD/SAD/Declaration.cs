﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class Declaration
    {
        string date; // Date type???
        string wholeValue;
        int kindOfImport; // or string???

        public Declaration(string Date, string value, int KindOfImport)
        {
            date = Date;
            wholeValue = value;
            kindOfImport = KindOfImport;
        }
    }
}
