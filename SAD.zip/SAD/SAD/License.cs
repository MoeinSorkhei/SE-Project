﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class License
    {
        string creationDate; // a better name?
        string expirationDate; // Date type for accessing DB??
        List<string> companies;
        List<string> countries;
        string maxPrice;
        string maxWeight;

        public License(string cDate, string eDate, List<string> companiesList,
                       List<string> countriesList, string price, string weight)
        {
            creationDate = cDate;
            expirationDate = eDate;
            maxPrice = price;
            maxWeight = weight;
            companies = new List<string>(companiesList);
            countries = new List<string>(countriesList);
        }
    }
}
