﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SAD
{
    public partial class MerchandiseInfo : Form
    {
        public MerchandiseInfo()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string[] lines = {textBox1.Text,
            //                  textBox2.Text,
            //                  textBox3.Text,
            //                  textBox4.Text,
            //                  textBox5.Text,
            //                  "###"};
            string path = @"C:\Users\monsieur maaz\Documents\Visual Studio 2010\Projects\SAD\SAD\Declarations.txt";
            using(StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine(textBox1.Text);
                sw.WriteLine(textBox2.Text);
                sw.WriteLine(textBox3.Text);
                sw.WriteLine(textBox4.Text);
                sw.WriteLine(textBox5.Text);
                sw.WriteLine("###");
            }

            //System.IO.File.WriteAllLines(@"C:\Users\monsieur maaz\Documents\Visual Studio 2010\Projects\SAD\SAD\Declarations.txt", lines);
            this.Close();
        }
    }
}
