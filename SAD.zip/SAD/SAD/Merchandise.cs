﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class Merchandise
    {
        private string name;
        private string country;
        private string company;
        public Merchandise(string merchandiseName, string countryName, string companyName)
        {
            name = merchandiseName;
            country = countryName;
            company = companyName;
        }
    }

   
}
