﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class LawMerchandise
    {
        private string minPrice;
        private string maxPrice;
        public LawMerchandise(string MinPrice, string MaxPrice)
        {
            minPrice = MinPrice;
            maxPrice = MaxPrice;
        }
    }
}
