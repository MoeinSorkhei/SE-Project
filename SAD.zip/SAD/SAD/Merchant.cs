﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class Merchant
    {
        MerchantLicense merchantLicense;
        List<Declaration> declarations;
        List<MerchantLicense> licenses;

    }
}
