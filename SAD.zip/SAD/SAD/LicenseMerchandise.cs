﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class LicenseMerchandise
    {
        string maxUnitPrice;
        string maxWeightPrice;
        License license;
        public LicenseMerchandise(string unitWight, string unitPrice)
        {
            maxUnitPrice = unitPrice;
            maxWeightPrice = unitWight;
        }
    }
}
