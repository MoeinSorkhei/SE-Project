﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAD
{
    class MerchantLicense
    {
        private string licenseNumber;
        License license;
    }
}
